"""
CopyCenterPlugin to provide the 'Comma Separated Value File' backend.

Description:
This python-script is a plugin for the CopyCenter.py.

Author:
Sebastian Sauer <mail@dipe.org>

Copyright:
GPL v2 or higher.
"""

class CopyCenterPlugin:
	""" The copycenterplugin to provide 'Comma Separated Value File' to
	DataCopy.py. """

	name = "Comma Separated Value File"
	""" The name this plugin has. The name should be unique and
	will be used for displaying a caption. """
	
	class Plugin:
		def _init_(self, copycenterplugin):
			self.copycenterplugin = copycenterplugin
			self.widget = None
			self.isfinished = True
			self.file = None
			
			self.options = {
				'file' : "~/data.txt",
				'dialect' : 'excel',
				'delimiter' : ',',
				'lineterminator' : '',
				'escapechar' : '',
				'doublequote' : True,
				'quotechar' : '"',
				'quoting' : False,
				'skipinitialspace' : False,
				'strict' : False,
			}
		def createWidget(self, dialog, parent):
			return self.copycenterplugin.widget(dialog, self, parent)
		def isFinished(self):
			return self.isfinished
		def _init(self, copierer):
			self.isfinished = False
			self.copierer = copierer
			
			filename = str(self.widget.fileedit.text())
			import re
			if re.search("^\\~(\\/|\\\\)",filename):
				import os
				filename = os.path.join(self.copycenterplugin.dialog.homepath,filename[2:])
			return filename
		def _finish(self):
			self.isfinished = True
			self.copierer = None

	class Source(Plugin):
		plugintype = "Source"
		def __init__(self,copycenterplugin):
			self._init_(copycenterplugin)
			#self.options += {}

		def init(self, copierer):
			filename = self._init(copierer)
			import csv
			try:
				self.file = open(filename,'r')
			except IOError:
				raise "No such CSV File: %s" % filename
			dialectname = str(self.widget.dialectcombo.currentText())
			if not dialectname in csv.list_dialects():
				CustomDialect = self.copycenterplugin.createCustomDialect(self)
				csv.register_dialect("custom",CustomDialect)
				dialectname = "custom"
			self.csvparser = csv.reader(self.file, dialect=dialectname)

			msg = "File: %sDialect: %s<br>" % (filename,dialectname)
			for item in dir(self.csvparser.dialect):
				if not item.startswith("_"):
					try:
						msg += " %s=%s" % (item, getattr(self.csvparser.dialect, item))
					except:
						pass
			copierer.appendProgressMessage(msg)

		def finish(self):
			self._finish()
			if self.file != None:
				self.file.close()
				self.file = None

		def read(self):
			try:
				record = self.csvparser.next()
			except StopIteration:
				return None
			#print "read record=%s" % str(record)
			return record

	class Destination(Plugin):
		plugintype = "Destination"
		def __init__(self,copycenterplugin):
			self._init_(copycenterplugin)
			self.options.update( {
				'operation' : 0, #0='replace' or 1='append'
			} )
		def init(self, copierer):
			filename = self._init(copierer)
			import csv

			if self.widget.opcombo.currentItem() == 0:
				self.file = open(filename,'w') # replace
			elif self.widget.opcombo.currentItem() == 1:
				self.file = open(filename,'a') # append
			else:
				raise "Unknown operation!"

			dialectname = str(self.widget.dialectcombo.currentText())
			if not dialectname in csv.list_dialects():
				CustomDialect = self.copycenterplugin.createCustomDialect(self)
				csv.register_dialect("custom",CustomDialect)
				dialectname = "custom"
			self.csvwriter = csv.writer(self.file, dialect=dialectname)

			msg = "File: %s<br>Dialect: %s<br>" % (filename,dialectname)
			for item in dir(self.csvwriter.dialect):
				if not item.startswith("_"):
					try:
						msg += " %s=%s" % (item, getattr(self.csvwriter.dialect, item))
					except:
						pass
			copierer.appendProgressMessage(msg)

		def finish(self):
			self._finish()
			if self.file != None:
				self.file.close()
				self.file = None

		def write(self, record):
			#print "write record=%s" % str(record)
			self.csvwriter.writerow( record )
			self.copierer.writeSuccess(record,1)

	def __init__(self, dialog):
		""" Constructor. """
		self.dialog = dialog

	def createCustomDialect(self, plugin):
		import csv
		class CustomDialect(csv.excel): pass
		setattr(CustomDialect, 'delimiter', plugin.widget.getOptionValue('delimiter'))
		setattr(CustomDialect, 'lineterminator', plugin.widget.getOptionValue('lineterminator'))
		escapechar = plugin.widget.getOptionValue('escapechar')
		if len(escapechar) != 1: escapechar = None
		setattr(CustomDialect, 'escapechar', escapechar)
		setattr(CustomDialect, 'doublequote', plugin.widget.getOptionValue('doublequote') == "True")
		quotechar = plugin.widget.getOptionValue('quotechar')
		if len(quotechar) != 1: quotechar = '"'
		setattr(CustomDialect, 'quotechar', quotechar)
		setattr(CustomDialect, 'quoting', plugin.widget.getOptionValue('quoting')  == "True")
		setattr(CustomDialect, 'skipinitialspace', plugin.widget.getOptionValue('skipinitialspace') == "True")
		setattr(CustomDialect, 'strict', plugin.widget.getOptionValue('strict') == "True")
		return CustomDialect

	def widget(self, dialog, plugin ,parent):
		""" Each plugin may provide a qt.QWidget back to the
		DataCopy.py. The widget will be used to configure our
		plugin settings. """

		import qt
		import os

		class MainWidget(qt.QHBox):
			def __init__(self, plugin, dialog, parent):
				import qt
				import csv
				qt.QHBox.__init__(self, parent)
				self.dialog = dialog
				self.plugin = plugin
				self.copycenterplugin = plugin.copycenterplugin
				self.mainbox = parent
	
				filebox = qt.QHBox(self.mainbox)
				filelabel = qt.QLabel("CSV File:", filebox)
				self.fileedit = qt.QLineEdit(self.plugin.options['file'], filebox)
				#self.fileedit.setText(os.path.join(self.dialog.getHomePath(),"kexidata.txt"))
				self.filebtn = qt.QPushButton("...",filebox)
				qt.QObject.connect(self.filebtn, qt.SIGNAL("clicked()"), self.fileButton)
				filelabel.setBuddy(self.fileedit)
				filebox.setStretchFactor(self.fileedit,1)

				if self.plugin.plugintype == "Destination":
					opbox = qt.QHBox(self.mainbox)
					oplabel = qt.QLabel("Operation:",opbox)
					self.opcombo = qt.QComboBox(opbox)
					self.opcombo.insertItem("Create/Replace File")
					self.opcombo.insertItem("Append to File")
					#self.opcombo.insertItem("Update File")
					self.opcombo.setCurrentItem(int(self.plugin.options['operation']))
					oplabel.setBuddy(self.opcombo)
					opbox.setStretchFactor(self.opcombo,1)

				dialectbox = qt.QHBox(self.mainbox)
				dialectlabel = qt.QLabel("Dialect:",dialectbox)
				self.dialectcombo = qt.QComboBox(dialectbox)
				for dialect in csv.list_dialects():
					self.dialectcombo.insertItem(dialect)
					if self.plugin.options['dialect'] == dialect:
						self.dialectcombo.setCurrentItem(self.dialectcombo.count() - 1)
				self.dialectcombo.insertItem("custom...")
				qt.QObject.connect(self.dialectcombo, qt.SIGNAL("activated(int)"), self.dialectActivated)
				dialectlabel.setBuddy(self.dialectcombo)
				dialectbox.setStretchFactor(self.dialectcombo,1)
				
				self.customdialectbox = qt.QVBox(self.mainbox)
				self.customdialectbox.setSpacing(2)

				dialectdelimiterbox = qt.QHBox(self.customdialectbox)
				dialectdelimiterlabel = qt.QLabel("Delimiter:",dialectdelimiterbox)
				self.dialectdelimiteredit = qt.QLineEdit(dialectdelimiterbox)
				dialectdelimiterlabel.setBuddy(self.dialectdelimiteredit)
				dialectdelimiterbox.setStretchFactor(self.dialectdelimiteredit,1)

				dialectlinetermbox = qt.QHBox(self.customdialectbox)
				dialectlinetermlabel = qt.QLabel("Line Terminator:",dialectlinetermbox)
				self.dialectlinetermedit = qt.QLineEdit(dialectlinetermbox)
				dialectlinetermlabel.setBuddy(self.dialectlinetermedit)
				dialectlinetermbox.setStretchFactor(self.dialectlinetermedit,1)

				dialectescapecharbox = qt.QHBox(self.customdialectbox)
				dialectescapecharlabel = qt.QLabel("Escape Char:",dialectescapecharbox)
				self.dialectescapecharedit = qt.QLineEdit(dialectescapecharbox)
				self.dialectescapecharedit.setMaxLength(1)
				dialectescapecharlabel.setBuddy(self.dialectescapecharedit)
				dialectescapecharbox.setStretchFactor(self.dialectescapecharedit,1)

				self.dialectdblquotecheck = qt.QCheckBox("Double Quote", self.customdialectbox)
				self.dialectdblquotecheck.setChecked(True)

				dialectquotecharbox = qt.QHBox(self.customdialectbox)
				dialectquotecharlabel = qt.QLabel("Quote Char:",dialectquotecharbox)
				self.dialectquotecharedit = qt.QLineEdit(dialectquotecharbox)
				self.dialectquotecharedit.setMaxLength(1)
				dialectquotecharlabel.setBuddy(self.dialectquotecharedit)
				dialectquotecharbox.setStretchFactor(self.dialectquotecharedit,1)

				self.dialectquotingcheck = qt.QCheckBox("Quoting", self.customdialectbox)
				self.dialectskipinitialspacecheck = qt.QCheckBox("Skip initial space", self.customdialectbox)
				self.dialectstrictcheck = qt.QCheckBox("Strict", self.customdialectbox)

				self.dialectActivated(0)

			def fileButton(self):
				filename = str(self.fileedit.text())
				if filename == "": filename = self.plugin.options['file']
				if self.plugin.plugintype == "Source":
					filename = qt.QFileDialog.getOpenFileName(
						filename, # initial file
						"*.csv *.txt;;*", # filtermask
						self.dialog) # parent
				elif self.plugin.plugintype == "Destination":
					filename = qt.QFileDialog.getSaveFileName(
						filename, # initial file
						"*.csv *.txt;;*", # filtermask
						self.dialog) # parent
				if filename != None and str(filename) != "":
					self.fileedit.setText(str(filename))

			def dialectActivated(self, index):
				import csv
				dialectname = str(self.dialectcombo.currentText())

				self.plugin.options['delimiter'] = str(self.dialectdelimiteredit.text())
				self.plugin.options['lineterminator'] = str(self.dialectlinetermedit.text())
				self.plugin.options['escapechar'] = str(self.dialectescapecharedit.text())
				self.plugin.options['doublequote'] = self.dialectdblquotecheck.isChecked()
				self.plugin.options['quotechar'] = str(self.dialectquotecharedit.text())
				self.plugin.options['quoting'] = self.dialectquotingcheck.isChecked()
				self.plugin.options['skipinitialspace'] = self.dialectskipinitialspacecheck.isChecked()
				self.plugin.options['strict'] = self.dialectstrictcheck.isChecked()

				if dialectname in csv.list_dialects():
					self.customdialectbox.setEnabled(False)
					dialect = csv.get_dialect(dialectname)
					if hasattr(dialect,'delimiter'): self.dialectdelimiteredit.setText( str(dialect.delimiter) )
					if hasattr(dialect,'lineterminator'): self.dialectlinetermedit.setText( str(dialect.lineterminator) )
					if hasattr(dialect,'escapechar'):
						if dialect.escapechar == None:
							self.dialectescapecharedit.setText( "" )
						else:
							self.dialectescapecharedit.setText( str(dialect.escapechar) )
					if hasattr(dialect,'doublequote'): self.dialectdblquotecheck.setChecked( dialect.doublequote )
					if hasattr(dialect,'quotechar'): self.dialectquotecharedit.setText( str(dialect.quotechar) )
					if hasattr(dialect,'quoting'): self.dialectquotingcheck.setChecked( dialect.quoting )
					if hasattr(dialect,'skipinitialspace'): self.dialectskipinitialspacecheck.setChecked( dialect.skipinitialspace )
					if hasattr(dialect,'strict'): self.dialectstrictcheck.setChecked( dialect.strict )
				else:
					self.customdialectbox.setEnabled(True)
					self.dialectdelimiteredit.setText( self.plugin.options['delimiter'] )
					self.dialectlinetermedit.setText( self.plugin.options['lineterminator'] )
					if self.plugin.options['escapechar'] == None:
						self.dialectescapecharedit.setText( "" )
					else:
						self.dialectescapecharedit.setText( self.plugin.options['escapechar'] )
					self.dialectdblquotecheck.setChecked( self.plugin.options['doublequote'] )
					self.dialectquotecharedit.setText( self.plugin.options['quotechar'] )
					self.dialectquotingcheck.setChecked( self.plugin.options['quoting'] )
					self.dialectskipinitialspacecheck.setChecked( self.plugin.options['skipinitialspace'] )
					self.dialectstrictcheck.setChecked( self.plugin.options['strict'] )

			def getOptionValue(self,optionname):
				try:
					if optionname == 'file': return str(self.fileedit.text())
					if optionname == 'operation': return str(self.opcombo.currentItem())
					if optionname == 'dialect': return str(self.dialectcombo.currentText())
					if optionname == 'delimiter': return str(self.dialectdelimiteredit.text())
					if optionname == 'lineterminator': return str(self.dialectlinetermedit.text())
					if optionname == 'escapechar': return str(self.dialectescapecharedit.text())
					if optionname == 'doublequote': return str(self.dialectdblquotecheck.isChecked())
					if optionname == 'quotechar': return str(self.dialectquotecharedit.text())
					if optionname == 'quoting': return str(self.dialectquotingcheck.isChecked())
					if optionname == 'skipinitialspace': return str(self.dialectskipinitialspacecheck.isChecked())
					if optionname == 'strict': return str(self.dialectstrictcheck.isChecked())
				except:
					pass
				return ""

		mainwidget = MainWidget(plugin, dialog, parent)
		plugin.widget = mainwidget
		return mainwidget

	