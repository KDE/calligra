"""
CopyCenterPlugin to provide the 'KSpread Spreadsheet' backend.

Description:
This python-script is a plugin for the CopyCenter.py.

Author:
Sebastian Sauer <mail@dipe.org>

Copyright:
GPL v2 or higher.
"""

class CopyCenterPlugin:
	""" The copycenterplugin to provide 'KSpread Spreadsheet' to DataCopy.py. """

	name = "KSpread Spreadsheet"

	class Plugin:
		def _init_(self, copycenterplugin):
			self.copycenterplugin = copycenterplugin
			self.widget = None
			self.isfinished = True
			self.file = None
			self.options = {
				'file' : "~/spreadsheet.ods",
				'sheet' : 'Sheet1',
			}
			import krosskspreadcore
			self.kspreaddoc = krosskspreadcore.get("KSpreadDocument")
		def createWidget(self, dialog, parent):
			return self.copycenterplugin.widget(dialog, self, parent)
		def isFinished(self):
			return self.isfinished
		def _init(self, copierer):
			self.isfinished = False
			self.copierer = copierer
		def _finish(self):
			self.isfinished = True
			self.copierer = None

	class Source(Plugin):
		plugintype = "Source"
		def __init__(self,copycenterplugin):
			self._init_(copycenterplugin)
		def init(self, copierer):
			self._init(copierer)
			sheetname = str( self.widget.sheetcombo.currentText() )
			self.copierer.appendProgressMessage("Sheet: %s" % sheetname)
			self.sheet = self.kspreaddoc.sheetByName(sheetname)
			self.row = 1
			firstcell = self.sheet.firstCell()
			self.maxrow = firstcell.row()
			self.maxcol = firstcell.column() + 1
		def finish(self):
			self._finish()
		def read(self):
			if self.row > self.maxrow:
				return None
			
			record = []
			for i in xrange(1, self.maxcol):
				cell = self.sheet.cell(i, self.row)
				if cell.value():
					record.append( cell.value() )
				else:
					record.append("")

			self.row += 1
			return record

	class Destination(Plugin):
		plugintype = "Destination"
		def __init__(self,copycenterplugin):
			self._init_(copycenterplugin)
		def init(self, copierer):
			self._init(copierer)
			sheetname = str( self.widget.sheetcombo.currentText() )
			self.copierer.appendProgressMessage("Sheet: %s" % sheetname)
			self.sheet = self.kspreaddoc.sheetByName(sheetname)
			if self.sheet == None:
				if not self.kspreaddoc.addSheet(sheetname):
					raise "Failed to create sheet \"%s\"" % sheetname
				self.sheet = self.kspreaddoc.sheetByName(sheetname)
			self.row = 1
		def finish(self):
			filename = str( self.widget.fileedit.text() )
			self.kspreaddoc.saveUrl(filename)
			self._finish()
		def write(self, record):
			col = 1
			print record
			for item in record:
				print "-----> %s" % item
				cell = self.sheet.cell(col,self.row)
				cell.setText( item )
				col += 1
			self.copierer.writeSuccess(record,1)
			self.row += 1

	def __init__(self, dialog):
		self.dialog = dialog

	def widget(self, dialog, plugin ,parent):
		import qt, os
		class MainWidget(qt.QHBox):
			def __init__(self, plugin, dialog, parent):
				import qt
				qt.QHBox.__init__(self, parent)
				self.dialog = dialog
				self.plugin = plugin
				self.copycenterplugin = plugin.copycenterplugin
				self.mainbox = parent
	
				filebox = qt.QHBox(self.mainbox)
				filelabel = qt.QLabel("Spreadsheet File:", filebox)
				self.fileedit = qt.QLineEdit(self.plugin.options['file'], filebox)
				qt.QObject.connect(self.fileedit, qt.SIGNAL("textChanged(const QString&)"), self.filenameChanged)
				self.filebtn = qt.QPushButton("...",filebox)
				qt.QObject.connect(self.filebtn, qt.SIGNAL("clicked()"), self.fileButton)
				filelabel.setBuddy(self.fileedit)
				filebox.setStretchFactor(self.fileedit,1)

				sheetbox = qt.QHBox(self.mainbox)
				sheetlabel = qt.QLabel("Sheet:", sheetbox)
				self.sheetcombo = qt.QComboBox(sheetbox)
				self.sheetcombo.setEditable(True)
				self.sheetcombo.setDuplicatesEnabled(False)
				sheetlabel.setBuddy(self.sheetcombo)
				sheetbox.setStretchFactor(self.sheetcombo,1)

				self.filenameChanged()

			def fileButton(self):
				filename = str(self.fileedit.text())
				if filename == "": filename = self.plugin.options['file']
				if self.plugin.plugintype == "Source":
					filename = qt.QFileDialog.getOpenFileName(
						filename, # initial file
						"*.ods;;*", # filtermask
						self.dialog) # parent
				elif self.plugin.plugintype == "Destination":
					filename = qt.QFileDialog.getSaveFileName(
						filename, # initial file
						"*.ods;;*", # filtermask
						self.dialog) # parent
				if filename != None and str(filename) != "":
					self.fileedit.setText(str(filename))

			def filenameChanged(self, *args):
				filename = str( self.fileedit.text() )
				import os, re
				if re.search("^\\~(\\/|\\\\)",filename):
					import os
					filename = os.path.join(self.copycenterplugin.dialog.homepath,filename[2:])
					self.fileedit.setText(filename) #recursive
					return

				self.sheetcombo.clear()
				if os.path.isfile(filename):
					self.plugin.kspreaddoc.openUrl(filename)
					for sheetname in self.plugin.kspreaddoc.sheetNames():
						self.sheetcombo.insertItem( sheetname )
				self.sheetcombo.setCurrentText( self.plugin.options['sheet'] )

			def getOptionValue(self,optionname):
				try:
					if optionname == 'file': return str( self.fileedit.text() )
					if optionname == 'sheet': return str(self.sheetcombo.currentText())
				except:
					pass
				return ""

		mainwidget = MainWidget(plugin, dialog, parent)
		plugin.widget = mainwidget
		return mainwidget

	