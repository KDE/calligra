""" WebServer module. """

class Module:
	def __init__(self, webserver, modulename):
		self.webserver = webserver
		self.modulename = modulename

	def request(self, clienthandler, path, query):
		import os
		file = os.path.join(self.webserver.scriptpath, os.path.join('files', path))
		print "file: %s" % file

		#clienthandler._write_header()
		#clienthandler._write("\"%s\"" % file)
		#return

		if file.endswith(".html"):
			clienthandler._write_header()
			f = open(file)
			clienthandler._write(f.read())
			clienthandler._write_footer()
			f.close()
		elif file.endswith(".css") or file.endswith(".txt"):
			clienthandler.send_response(200)
			clienthandler.send_header('Content-type','text/html')
			clienthandler.end_headers()
			f = open(file)
			clienthandler._write(f.read())
			f.close()
