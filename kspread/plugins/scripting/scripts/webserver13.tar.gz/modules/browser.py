""" WebServer module. """

class Module:
	def __init__(self, webserver, modulename):
		self.webserver = webserver
		self.modulename = modulename
		self.config = self.webserver.config['modules'][self.modulename]
		self.connections = {}
		self.connectionname = ""

		try:
			import krosskexidb
			self.kexidbdrivermanager = krosskexidb.DriverManager()
		except:
			raise "Failed to import the Kross KexiDB module. Please use krossrunner or Kexi to execute the WebServer python script."

		for connection in self.config['moduledom'].getElementsByTagName("Connection"):
			name = str(connection.getAttribute('name'))
			projectfile = str(connection.getAttribute('project'))
			
			if not os.path.isfile(projectfile):
				file = os.path.join(scriptpath,projectfile)
				if not os.path.isfile(file):
					raise "Projectfile \"%s\" for Connection \"%s\" does not exist." % (projectfile,name)
				projectfile = file

			connectiondata = self.kexidbdrivermanager.createConnectionDataByFile(projectfile)
			if connectiondata == None:
				raise "Unsupported projectfile \"%s\" in Connection \"%s\"." % (projectfile,name)

			driver = self.kexidbdrivermanager.driver( connectiondata.driverName() )
			if driver == None:
				raise "Unsupported driver \"%s\" for projectfile \"%s\" in Connection \"%s\"." % (connectiondata.driverName(),projectfile,name)

			kexidbconnection = driver.createConnection(connectiondata)

			if not kexidbconnection.isConnected():
				if not kexidbconnection.connect():
					raise "Failed to connect with \"%s\"" % connectiondata.serverInfoString()

			self.connections[name] = kexidbconnection
			if self.connectionname == "":
				self.connectionname = name
				print "Added Connection \"%s\" as default connection" % connectiondata.serverInfoString()
			else:
				print "Added Connection \"%s\"" % connectiondata.serverInfoString()

	def showIndex(self, clienthandler):
		import urllib

		connection = self.connections[ self.connectionname ]

		clienthandler._write("<table>"
			"<tr>"
			"<th>Tablename</th>"
			"<th>Fields</th>"
			"</tr>\n")

		for tablename in connection.tableNames():
			tableschema = connection.tableSchema(tablename)
			caption = str(tableschema.caption())
			if caption == "": caption = tableschema.name()

			fields = []
			for field in tableschema.fieldlist().fields():
				fields.append( str(field.name()) )

			clienthandler._write("<tr>"
				"<td valign=\"top\"><a href=\"/browser?query=select+*+from+%s&connection=%s\">%s</a></td>"
				"<td>%s</td></tr>\n" %
					(urllib.quote(tablename), self.connectionname, caption, ", ".join(fields)))

		clienthandler._write('</table>')

	def showQueryResult(self, clienthandler, query, qs):
		import urllib
		kexidbconnection = self.connections[ self.connectionname ]

		cursor = kexidbconnection.executeQueryString(qs)
		if not cursor:
			clienthandler._write("Failed to execute the query \"%s\".<br/><br/>%s" % (qs,kexidbconnection.lastError()))
			clienthandler._write_footer()
			return

		try: page = int(query['page'][0])
		except: page = 1
		try: perpage = int(query['perpage'][0])
		except: perpage = 50

		quotedqs = urllib.quote(qs)
		quotedconnectionname = urllib.quote(self.connectionname)
		clienthandler._write("<div id=\"pagenav\"><a href=\"/browser?query=%s&connection=%s&page=%i&perpage=%i\">&lt;&lt;Prev</a>" % (quotedqs, quotedconnectionname, page - 1, perpage) )
		clienthandler._write(" Page: %i " % page)
		clienthandler._write("<a href=\"/browser?query=%s&connection=%s&page=%i&perpage=%i\">Next &gt;&gt;</a></div>" % (quotedqs, quotedconnectionname, page + 1, perpage) )

		clienthandler._write("<table><tr><th>&nbsp;</th>")
		for i in range(1, cursor.fieldCount() + 1 ):
			clienthandler._write("<th>%s</th>" % i)
		clienthandler._write("</tr>\n")

		startnum = page * perpage - (perpage - 1)
		endnum = startnum + (perpage - 1)
		num = 1
		if startnum >= 1:
			ok = cursor.moveFirst()
			while ok:
				if num >= startnum:
					clienthandler._write("<tr><th>%s</th>" % num)
					for i in range( cursor.fieldCount() ):
						clienthandler._write("<td>%s</td>" % cursor.value(i))
					clienthandler._write("</tr>\n")
					if num >= endnum:
						break
				num += 1
				ok = cursor.moveNext()
		clienthandler._write("</table>\n")

	def request(self, clienthandler, path, query):
		import urllib
		clienthandler._write_header()

		try: self.connectionname = "".join(query['connection'])
		except: pass

		try: kexidbconnection = self.connections[ self.connectionname ]
		except KeyError:
			clienthandler._write("No such connection \"%s\"" % self.connectionname)
			clienthandler._write_footer()
			return

		if not kexidbconnection.isDatabaseUsed():
			connectiondata = kexidbconnection.data()
			if not kexidbconnection.useDatabase( connectiondata.databaseName() ):
				if not kexidbconnection.useDatabase( connectiondata.fileName() ):
					clienthandler._write("Error: No such connection \"%s\"" % self.connectionname)
					clienthandler._write_footer()
					return

		#print "CONNECTION: \"%s\"" % str( self.connectionname )
		try: 
			qs = "".join(query['query'])
			try:
				# Check to be sure to don't pass for example
				# a "drop table mytabable" to executeQuery().
				kexidbparser = kexidbconnection.parser()
				kexidbparser.parse(qs)
				op = kexidbparser.operation()
				if op == 'Error':
					clienthandler._write(kexidbparser.errorMsg())
					clienthandler._write_footer()
					return
				if op != 'Select':
					clienthandler._write("Operation \"%s\" denied." % op)
					clienthandler._write_footer()
					return
			except:
				import sys, traceback
				clienthandler._write( "<br>".join( traceback.format_exception(sys.exc_info()[0],sys.exc_info()[1],sys.exc_info()[2]) ) )
				clienthandler._write_footer()
				return
		except KeyError: qs = ""

		clienthandler._write("<form action=\"/browser\">"
			"<label for=\"connection\">Connection:</label> "
			"<select id=\"connection\" name=\"connection\" size=\"1\">")
		conlist = self.connections.keys()
		conlist.sort()

		for conname in self.connections.keys():
			s = (conname == self.connectionname and " selected=\"1\"") or ""
			clienthandler._write("<option value=\"%s\"%s> %s </option>" % (conname,s,conname))
		clienthandler._write("</select> "
			"<input type=\"submit\" value=\"Select\" />"
			"</form>\n")

		try: page = int(query['page'][0])
		except: page = 1
		try: perpage = int(query['perpage'][0])
		except: perpage = 50

		clienthandler._write("<form action=\"/browser\">"
			"<label for=\"query\">Query:</label> <input type=\"text\" id=\"query\" name=\"query\" value=\"%s\" size=\"30\" maxlength=\"1000\" /> <input type=\"submit\" value=\"Search\" /><br />"
			"<label for=\"page\">Page:</label> <input type=\"text\" id=\"page\" name=\"page\" value=\"%i\" size=\"5\" maxlength=\"100\" /> "
			"<label for=\"perpage\">Records per page:</label> <input type=\"text\" id=\"perpage\" name=\"perpage\" value=\"%i\" size=\"5\" maxlength=\"100\" />"
		"</form>\n" % (qs, page, perpage))

		if qs == "":
			self.showIndex(clienthandler)
		else:
			self.showQueryResult(clienthandler, query, qs)
		clienthandler._write_footer()
