""" OpenDocument spreadsheet module. """

class Module:
	def __init__(self, webserver, modulename):
		self.webserver = webserver
		self.modulename = modulename
		self.config = self.webserver.config['modules'][self.modulename]

		try:
			import krosskspreadcore
			self.kspreaddoc = krosskspreadcore.get("KSpreadDocument")
		except:
			raise "Failed to import the Kross KSpread module. Please use krossrunner or KSpread to execute the WebServer python script."

		try:
			node = self.config['moduledom']
			elem = node.getElementsByTagName("spreadsheet")[0]
			self.odsfile = str( elem.getAttribute('odsfile') )
		except (KeyError,IndexError):
			raise "No Spreadsheet File defined."

		if not os.path.isfile(self.odsfile):
			raise "The Spreadsheet File %2 does not exist"

		try:
			self.kspreaddoc.openUrl(self.odsfile)
			print "Loaded Spreadsheet File: %s" % self.odsfile
		except:
			raise "Failed to load the OpenDocument Spreadsheet File %s" % self.odsname

		#for connection in self.config['moduledom'].getElementsByTagName("Connection"):
			#name = str(connection.getAttribute('name'))
			#projectfile = str(connection.getAttribute('project'))
			#if not os.path.isfile(projectfile):
				#file = os.path.join(scriptpath,projectfile)
				#if not os.path.isfile(file):
					#raise "Projectfile \"%s\" for Connection \"%s\" does not exist." % (projectfile,name)
				#projectfile = file
			#connectiondata = self.kexidbdrivermanager.createConnectionDataByFile(projectfile)
			#if connectiondata == None:
				#raise "Unsupported projectfile \"%s\" in Connection \"%s\"." % (projectfile,name)
			#driver = self.kexidbdrivermanager.driver( connectiondata.driverName() )
			#if driver == None:
				#raise "Unsupported driver \"%s\" for projectfile \"%s\" in Connection \"%s\"." % (connectiondata.driverName(),projectfile,name)
			#kexidbconnection = driver.createConnection(connectiondata)
			#if not kexidbconnection.isConnected():
				#if not kexidbconnection.connect():
					#raise "Failed to connect with \"%s\"" % connectiondata.serverInfoString()
			#self.connections[name] = kexidbconnection
			#if self.connectionname == "":
				#self.connectionname = name
				#print "Added Connection \"%s\" as default connection" % connectiondata.serverInfoString()
			#else:
				#print "Added Connection \"%s\"" % connectiondata.serverInfoString()

	def showIndex(self, clienthandler):
		clienthandler._write("<ul>")
		for sheet in self.kspreaddoc.sheetNames():
			clienthandler._write("<li><a href=\"/spreadsheet?sheet=%s\">%s</a></li>" % (sheet,sheet))
		clienthandler._write("</ul>")

	def showSheet(self, clienthandler, sheetname):
		print "showSheet: %s" % sheetname

		sheet = self.kspreaddoc.sheetByName(sheetname)
		if not sheet:
			clienthandler._write("No such sheet: %s" % sheetname)
			return
		
		firstcell = sheet.firstCell()
		maxrow = firstcell.row()
		maxcol = firstcell.column() + 1
		
		clienthandler._write("<table><tr><th>&nbsp;</th>")
		for c in xrange(1, maxcol):
			clienthandler._write("<th>%s</th>" % c)
		clienthandler._write("</tr>")
		
		for r in xrange(0, maxrow):
			clienthandler._write("<tr><th>%s</th>" % (r + 1))
			for c in xrange(1, maxcol):
				cell = sheet.cell(c, r)
				v = cell.value()
				if v == None:
					v = ""
				clienthandler._write("<td>%s</td>" % v)
			clienthandler._write("</tr>")
		clienthandler._write("</table>")

	def request(self, clienthandler, path, query):
		import urllib
		clienthandler._write_header()

		try: sheetname = "".join(query['sheet'])
		except: sheetname = ""
		
		for sheet in self.kspreaddoc.sheetNames():
			if sheetname == sheet:
				clienthandler._write("<b>%s</b> " % sheet)
			else:
				clienthandler._write("<a href=\"/spreadsheet?sheet=%s\">%s</a> " % (sheet,sheet))
		
		if sheetname == "":
			self.showIndex(clienthandler)
		else:
			self.showSheet(clienthandler, sheetname)

		clienthandler._write_footer()
