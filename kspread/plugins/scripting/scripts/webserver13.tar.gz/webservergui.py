#!/usr/bin/python

import qt

def appAboutToQuit():
	""" This function got called if the main application qt.qApp got closed.
	In that case we need to stop all running threads else they block the still
	running but invisible main application from quitting. """
	global _main_webserverthreads
	for name in _main_webserverthreads.keys():
		print "Kill Web Server \"%s\"" % name
		_main_webserverthreads[name].stop()
	_main_webserverthreads.clear()

class EditServer(qt.QVBox):
	def __init__(self, editor, parent):
		import os, qt, re
		self.editor = editor
		self.filespath = os.path.join(self.editor.maindialog.scriptpath, 'files')

		qt.QHBox.__init__(self, parent)
		qt.QLabel("<b>Server</b> - HTTP-Server configuration.", self)

		box = qt.QHBox(self)
		qt.QLabel("Address:", box)
		self.addressedit = qt.QLineEdit(box)
		self.addressedit.setText(self.editor.domservernode.getAttribute('address'))

		box = qt.QHBox(self)
		qt.QLabel("Port:", box)
		self.portedit = qt.QLineEdit(box)
		self.portedit.setText(self.editor.domservernode.getAttribute('port'))

		box = qt.QHBox(self)
		qt.QLabel("Homepage:", box)
		self.homecombo = qt.QComboBox(box)
		self.homecombo.setEditable(True)
		self.homecombo.insertItem("/browser")
		self.homecombo.insertItem("/spreadsheet")
		self.homecombo.insertItem("/files/index.html")
		self.homecombo.setCurrentText(self.editor.domservernode.getAttribute('homepage'))
		box.setStretchFactor(self.homecombo, 1)

		box = qt.QHBox(self)
		qt.QLabel("Title:", box)
		self.titleedit = qt.QLineEdit(box)
		self.titleedit.setText(self.editor.domservernode.getAttribute('title'))

		box = qt.QHBox(self)
		qt.QLabel("Caption:", box)
		self.captionedit = qt.QLineEdit(box)
		self.captionedit.setText(self.editor.domservernode.getAttribute('caption'))

		box = qt.QHBox(self)
		qt.QLabel("Style:", box)
		self.stylecombo = qt.QComboBox(box)
		box.setStretchFactor(self.stylecombo, 1)

		style = self.editor.domservernode.getAttribute('style')
		regexp = re.compile('(.+)\\.css$')
		for f in os.listdir(self.filespath):
			file = os.path.join(self.filespath, f)
			if not os.path.isfile(file): continue
			m = regexp.match(f)
			if not m: continue
			stylename = os.path.basename(file)
			self.stylecombo.insertItem(stylename)
			if style == stylename:
				self.stylecombo.setCurrentItem(self.stylecombo.count() - 1)

		self.setStretchFactor(qt.QWidget(self), 1)

	def saveDOM(self):
		self.editor.domservernode.setAttribute('address', str(self.addressedit.text()))
		self.editor.domservernode.setAttribute('port', str(self.portedit.text()))
		self.editor.domservernode.setAttribute('homepage', str(self.homecombo.currentText()))
		self.editor.domservernode.setAttribute('title', str(self.titleedit.text()))
		self.editor.domservernode.setAttribute('caption', str(self.captionedit.text()))
		self.editor.domservernode.setAttribute('style', str(self.stylecombo.currentText()))

class EditBrowser(qt.QVBox):
	def __init__(self, editor, parent):
		import qt
		self.editor = editor
		qt.QHBox.__init__(self, parent)
		qt.QLabel("<b>Browser</b> - Browse KexiDB queries.", self)

		editor.browseritem.setOn(editor.dommodules.has_key('browser'))
		#try: browserfile = editor.dommodules['browser']['file']
		#except KeyError: browserfile = None
		try: browsernode = editor.dommodules['browser']['moduledom']
		except KeyError: browsernode = None

		b = qt.QHBox(self)
		newbtn = qt.QPushButton("New", b)
		qt.QObject.connect(newbtn, qt.SIGNAL("clicked()"),self.newbtnClicked)
		self.clonebtn = qt.QPushButton("Clone", b)
		self.clonebtn.setEnabled(False)
		qt.QObject.connect(self.clonebtn, qt.SIGNAL("clicked()"),self.clonebtnClicked)
		self.delbtn = qt.QPushButton("Delete", b)
		self.delbtn.setEnabled(False)
		qt.QObject.connect(self.delbtn, qt.SIGNAL("clicked()"),self.delbtnClicked)

		self.listview = qt.QListView(self)
		self.listview.addColumn("Connection")
		self.listview.addColumn("Projectfile")
		self.listview.setAllColumnsShowFocus(True)
		qt.QObject.connect(self.listview, qt.SIGNAL("selectionChanged()"), self.listSelectionChanged)

		if browsernode != None:
			for connection in browsernode.getElementsByTagName("Connection"):
				item = qt.QListViewItem(self.listview)
				item.setText(0, str(connection.getAttribute('name')))
				item.setText(1, str(connection.getAttribute('project')))

		self.box = qt.QVBox(self)
		self.box.setEnabled(False)
		self.box.setSpacing(4)
		
		namebox = qt.QHBox(self.box)
		qt.QLabel("Name:", namebox)
		self.nameedit = qt.QLineEdit(namebox)
		qt.QObject.connect(self.nameedit, qt.SIGNAL("textChanged(const QString&)"),self.nameeditChanged)

		prjbox = qt.QHBox(self.box)
		qt.QLabel("Project File:", prjbox)
		self.prjedit = qt.QLineEdit(prjbox)
		qt.QObject.connect(self.prjedit, qt.SIGNAL("textChanged(const QString&)"),self.prjeditChanged)
		prjbtn = qt.QPushButton("...", prjbox)
		qt.QObject.connect(prjbtn, qt.SIGNAL("clicked()"),self.prjbtnClicked)

	def listSelectionChanged(self):
		selected = self.listview.selectedItem() != None
		self.box.setEnabled(selected)
		self.clonebtn.setEnabled(selected)
		self.delbtn.setEnabled(selected)
		if selected:
			self.nameedit.setText( self.listview.selectedItem().text(0) )
			self.prjedit.setText( self.listview.selectedItem().text(1) )
		else:
			self.nameedit.setText("")
			self.prjedit.setText("")

	def nameeditChanged(self, text):
		try: self.listview.selectedItem().setText(0, text)
		except: pass

	def prjeditChanged(self, text):
		try: self.listview.selectedItem().setText(1, text)
		except: pass

	def prjbtnClicked(self):
		filename = qt.QFileDialog.getOpenFileName(str(self.prjedit.text()),"*.kexi *.kexis *.kexic;;*", self.editor)
		if str(filename) != "": self.prjedit.setText(str(filename))

	def newbtnClicked(self):
		item = qt.QListViewItem(self.listview)
		item.setText(0, "Unnamed")
		item.setText(1, "")
		self.listview.setSelected(item, True)

	def clonebtnClicked(self):
		item = qt.QListViewItem(self.listview)
		item.setText(0, self.listview.selectedItem().text(0))
		item.setText(1, self.listview.selectedItem().text(1))
		self.listview.setSelected(item, True)

	def delbtnClicked(self):
		item = self.listview.selectedItem()
		n = item.nextSibling()
		self.listview.takeItem(item)
		if not n: n = self.listview.firstChild()
		if n: self.listview.setSelected(n, True)

	def saveDOM(self):
		if not self.editor.dommodules.has_key('browser'): return
		browsernode = self.editor.dommodules['browser']['moduledom']
		browsernode.childNodes = []
		item = self.listview.firstChild()
		while item:
			node = self.editor.domdoc.createElementNS('','Connection')
			node.setAttribute('name', str(item.text(0)))
			node.setAttribute('project', str(item.text(1)))
			browsernode.childNodes.append(node)
			item = item.nextSibling()

class EditSpreadsheet(qt.QVBox):
	def __init__(self, editor, parent):
		import qt
		self.editor = editor
		qt.QHBox.__init__(self, parent)
		qt.QLabel("<b>Spreadsheet</b> - Edit an OpenDocument Spreadsheet file.", self)

		try:
			node = editor.dommodules['spreadsheet']['moduledom']
			elem = node.getElementsByTagName("spreadsheet")[0]
			odsfile = elem.getAttribute('odsfile')
		except (KeyError,IndexError):
			odsfile = ""

		filebox = qt.QHBox(self)
		qt.QLabel("Spreadsheet File:", filebox)
		self.fileedit = qt.QLineEdit(odsfile, filebox)
		filebtn = qt.QPushButton("...", filebox)
		qt.QObject.connect(filebtn, qt.SIGNAL("clicked()"),self.filebtnClicked)

		editor.spreadsheetitem.setOn(editor.dommodules.has_key('spreadsheet'))
		self.setStretchFactor(qt.QWidget(self), 1)

	def filebtnClicked(self):
		filename = qt.QFileDialog.getOpenFileName(str(self.fileedit.text()),"*.ods;;*", self.editor)
		if str(filename) != "": self.fileedit.setText(str(filename))

	def saveDOM(self):
		if not self.editor.dommodules.has_key('spreadsheet'): return
		spreadsheetnode = self.editor.dommodules['spreadsheet']['moduledom']
		node = self.editor.domdoc.createElementNS('','spreadsheet')
		node.setAttribute('odsfile', str(self.fileedit.text()))
		spreadsheetnode.childNodes.append(node)

class EditFiles(qt.QVBox):
	def __init__(self, editor, parent):
		import qt
		qt.QHBox.__init__(self, parent)
		qt.QLabel("<b>Files</b> - Stream files from the files-directory.", self)
		editor.filesitem.setOn(editor.dommodules.has_key('files'))
		self.setStretchFactor(qt.QWidget(self), 1)

	def saveDOM(self):
		pass

class Editor(qt.QDialog):
	def __init__(self, maindialog, filename):
		import os, sys, qt, xml.dom.minidom
		self.maindialog = maindialog
		self.filename = filename

		self.domdoc = xml.dom.minidom.parse(filename)
		self.domservernode = self.domdoc.getElementsByTagName("Server")[0]
		self.dommodules = {}
		for dommodule in self.domservernode.getElementsByTagName("Module"):
			name = dommodule.getAttribute('name')
			self.dommodules[name] = {'moduledom' : dommodule}

		qt.QDialog.__init__(self, maindialog, "EditDialog", 1, qt.Qt.WDestructiveClose)
		self.setCaption("Edit webserver configuration \"%s\"" % os.path.basename(filename)[:-4])
		layout = qt.QVBoxLayout(self)
		box = qt.QVBox(self)
		box.setMargin(10)
		box.setSpacing(10)
		layout.addWidget(box)

		splitter = qt.QSplitter(box)
		box.setStretchFactor(splitter, 1)

		self.listview = qt.QListView(splitter)
		splitter.setResizeMode(self.listview, qt.QSplitter.KeepSize)
		self.listview.addColumn("")
		#self.listview.header().setClickEnabled(False)
		self.listview.header().hide()
		self.listview.setAllColumnsShowFocus(True)
		self.listview.header().setStretchEnabled(True, 0)
		self.listview.setSorting(-1)
		self.listview.setFocus()

		self.serveritem = qt.QListViewItem(self.listview)
		self.serveritem.setText(0, 'server')
		self.serveritem.setSelected(True)
		self.browseritem = qt.QCheckListItem(self.listview, self.serveritem, 'browser', qt.QCheckListItem.CheckBox)
		self.spreadsheetitem = qt.QCheckListItem(self.listview, self.browseritem, 'spreadsheet', qt.QCheckListItem.CheckBox)
		self.filesitem = qt.QCheckListItem(self.listview, self.spreadsheetitem, 'files', qt.QCheckListItem.CheckBox)

		self.modulestack = qt.QWidgetStack(splitter)
		global EditServer, EditConfig, EditBrowser, EditSpreadsheet, EditFiles
		self.modules = {'server':EditServer, 'browser':EditBrowser, 'spreadsheet':EditSpreadsheet, 'files':EditFiles}
		for modulename in self.modules.keys():
			module = self.modules[modulename](self, self.modulestack)
			module.setSpacing(4)
			self.modules[modulename] = module
			self.modulestack.addWidget(module)

		btnbox = qt.QHBox(box)
		btnbox.setSpacing(6)
		self.okbtn = qt.QPushButton("Save", btnbox)
		self.okbtn.setDefault(True)
		qt.QObject.connect(self.okbtn, qt.SIGNAL("clicked()"), self.saveClicked)
		self.cancelbtn = qt.QPushButton("Cancel", btnbox)
		qt.QObject.connect(self.cancelbtn, qt.SIGNAL("clicked()"), self.close)

		box.setMinimumSize( qt.QSize(560,400) )
		qt.QObject.connect(self.listview, qt.SIGNAL("selectionChanged()"), self.listSelectionChanged)
		self.listSelectionChanged()

	def listSelectionChanged(self):
		import qt
		item = self.listview.selectedItem()
		if item != None: self.modulestack.raiseWidget( self.modules[ str(item.text(0)) ] )

	def updateDOM(self, modulename):
		try: ison = getattr(self, "%sitem" % modulename).isOn()
		except: return
		if ison: # The module is activated. Prepare the XML DOM node for the module.
			if not self.dommodules.has_key(modulename):
				dommodulenode = self.domdoc.createElementNS('','Module')
				dommodulenode.setAttribute('name', modulename)
				self.dommodules[modulename] = {'moduledom' : dommodulenode}
				self.domservernode.childNodes.append(dommodulenode)
		else: # The module is deactivated. Remove the XML DOM node the module had before.
			if not self.dommodules.has_key(modulename): return
			node = self.dommodules[modulename]['moduledom']
			self.dommodules.__delitem__(modulename)
			self.domservernode.removeChild(node)

	def saveClicked(self):
		import xml.dom.minidom, xml.dom.ext
		try:
			for modulename in self.modules.keys():
				self.updateDOM(modulename)
				self.modules[modulename].saveDOM()
			f = open(self.filename, "w")
			xml.dom.ext.PrettyPrint(self.domdoc, f)
			f.close()
			self.close()
		except:
			import sys, traceback
			qt.QMessageBox.critical(self,'Save failed', "".join( traceback.format_exception(sys.exc_info()[0],sys.exc_info()[1],sys.exc_info()[2]) ))

class MainDialog(qt.QDialog):
	def __init__(self, scriptpath):
		import os, sys, qt
		qt.QDialog.__init__(self, qt.qApp.mainWidget(), "MainDialog", 1, qt.Qt.WDestructiveClose)
		global appAboutToQuit
		qt.QObject.connect(qt.qApp, qt.SIGNAL("aboutToQuit()"), appAboutToQuit)

		self.scriptpath = scriptpath
		self.setCaption("Web Server")
		layout = qt.QVBoxLayout(self)
		box = qt.QHBox(self)
		box.setMargin(10)
		box.setSpacing(10)
		layout.addWidget(box)

		self.listview = qt.QListView(box)
		self.listview.addColumn("Name")
		self.listview.addColumn("State")
		#self.listview.header().setClickEnabled(False)
		self.listview.header().hide()
		self.listview.setAllColumnsShowFocus(True)
		self.listview.header().setStretchEnabled(True, 0)
		self.listview.setFocus()
		qt.QObject.connect(self.listview, qt.SIGNAL("selectionChanged()"), self.updateStates)
		box.setStretchFactor(self.listview, 1)

		btnbox = qt.QVBox(box)
		btnbox.setSpacing(6)

		#qt.QObject.connect(qt.QPushButton("Refresh", btnbox), qt.SIGNAL("clicked()"), self.reloadListView)
		#qt.QFrame(btnbox).setFrameStyle(qt.QFrame.Sunken | qt.QFrame.HLine)
		self.newbtn = qt.QPushButton("New...", btnbox)
		qt.QObject.connect(self.newbtn, qt.SIGNAL("clicked()"), self.newClicked)
		self.editbtn = qt.QPushButton("Edit...", btnbox)
		self.editbtn.setDefault(True)
		qt.QObject.connect(self.editbtn, qt.SIGNAL("clicked()"), self.editClicked)
		self.renamebtn = qt.QPushButton("Rename...", btnbox)
		qt.QObject.connect(self.renamebtn, qt.SIGNAL("clicked()"), self.renameClicked)
		self.delbtn = qt.QPushButton("Delete", btnbox)
		qt.QObject.connect(self.delbtn, qt.SIGNAL("clicked()"), self.delClicked)
		qt.QFrame(btnbox).setFrameStyle(qt.QFrame.Sunken | qt.QFrame.HLine)
		self.startbtn = qt.QPushButton("Start", btnbox)
		qt.QObject.connect(self.startbtn, qt.SIGNAL("clicked()"), self.startClicked)
		self.stopbtn = qt.QPushButton("Stop", btnbox)
		qt.QObject.connect(self.stopbtn, qt.SIGNAL("clicked()"), self.stopClicked)
		btnbox.setStretchFactor(qt.QWidget(btnbox), 1)

		box.setMinimumSize( qt.QSize(420,360) )
		self.reloadListView()
		#self.editClicked() #TESTCASE!

	def reloadListView(self):
		import os, re, qt
		if self.listview.selectedItem():
			seltext = self.listview.selectedItem().text(0)
		else:
			seltext = None
		self.listview.clear()
		configpath = os.path.join(self.scriptpath, 'configs')
		regexp = re.compile('(.+)\\.xml$')
		for f in os.listdir(configpath):
			file = os.path.join(configpath, f)
			if not os.path.isfile(file): continue
			m = regexp.match(f)
			if not m: continue
			name = m.group(1)
			item = qt.QListViewItem(self.listview)
			item.setText(0, name)
			global _main_webserverthreads
			if _main_webserverthreads.has_key(name):
				item.setText(1, 'Running')
			else:
				item.setText(1, 'Stopped')
			if seltext != None and seltext == name:
				self.listview.setSelected(item, True)
				
		if not self.listview.selectedItem() and self.listview.childCount() > 0:
			self.listview.setSelected(self.listview.firstChild(), True)
		if self.listview.selectedItem():
			self.listview.ensureItemVisible(self.listview.selectedItem())
		self.updateStates()

	def updateStates(self):
		selected = (self.listview.selectedItem() != None)
		if selected:
			global _main_webserverthreads
			running = _main_webserverthreads.has_key( str(self.listview.selectedItem().text(0)) )
		self.editbtn.setEnabled(selected)
		self.renamebtn.setEnabled(selected and not running)
		self.delbtn.setEnabled(selected and not running)
		self.startbtn.setEnabled(selected and not running)
		self.stopbtn.setEnabled(selected and running)

	def newClicked(self):
		import os, sys
		text, ok = qt.QInputDialog.getText('New...','Name of the new webserver configuration:',qt.QLineEdit.Normal,"")
		if str(text) == "" or not ok: return
		filename = os.path.join(self.scriptpath,os.path.join('configs',"%s.xml" % text))
		if os.path.isfile(filename):
			if qt.QMessageBox.question(self,'Overwrite?',"<qt>There exists already such a webserver configuration \"%s\".<br><br>Overwrite that file?</qt>" % filename, qt.QMessageBox.Yes, qt.QMessageBox.Cancel) != qt.QMessageBox.Yes:
				return
		try:
			f = open(filename,"w")
			f.write("<WebServer>")
			f.write("  <Server address=\"127.0.0.1\" port=\"8282\" homepage=\"/browser\" title=\"WebServer\" caption=\"WebServer\" style=\"simple.css\">")
			f.write("    <Module name=\"browser\" />")
			f.write("    <Module name=\"files\" />")
			f.write("  </Server>")
			f.write("</WebServer>")
			f.close()

			item = qt.QListViewItem(self.listview)
			item.setText(0, str(text))
			self.listview.setSelected(item, True)
			self.reloadListView()
			if str(self.listview.selectedItem().text(0)) == str(text):
				qt.QTimer.singleShot(10, self.editClicked)
		except:
			qt.QMessageBox.critical(self,'Create failed',"<qt>Failed to create the new webserver configuration \"%s\".<br><br>%s</qt>" % (filename,str(sys.exc_info()[1])))

	def editClicked(self):
		import os, sys
		global Editor
		if self.listview.selectedItem() == None: return
		filename = os.path.join(self.scriptpath,os.path.join('configs',"%s.xml" % str(self.listview.selectedItem().text(0))))
		editdialog = Editor(self, filename)
		editdialog.show()

	def renameClicked(self):
		import os, sys
		oldname = str(self.listview.selectedItem().text(0))
		newname, ok = qt.QInputDialog.getText('Rename...','Rename the webserver configuration:',qt.QLineEdit.Normal,oldname)
		if str(newname) == "" or not ok: return
		configpath = os.path.join(self.scriptpath,'configs')
		oldname = os.path.join(configpath,"%s.xml" % oldname)
		newname = os.path.join(configpath,"%s.xml" % newname)
		if os.path.isfile(newname):
			if qt.QMessageBox.question(self,'Overwrite?',"<qt>There exists already such a webserver configuration \"%s\".<br><br>Overwrite that file?</qt>" % newname, qt.QMessageBox.Yes, qt.QMessageBox.Cancel) != qt.QMessageBox.Yes:
				return
		try:
			os.rename(oldname, newname)
			self.reloadListView()
		except:
			qt.QMessageBox.critical(self,'Rename failed',"<qt>Failed to rename \"%s\" to \"%s\".<br><br>%s</qt>" % (oldname,newname,str(sys.exc_info()[1])))

	def delClicked(self):
		import os, sys
		filename = os.path.join(self.scriptpath,os.path.join('configs',"%s.xml" % str(self.listview.selectedItem().text(0))))
		if qt.QMessageBox.question(self,'Delete?',"<qt>Really delete the webserver configuration \"%s\"?</qt>" % filename, qt.QMessageBox.Yes, qt.QMessageBox.Cancel) != qt.QMessageBox.Yes:
			return
		try:
			os.remove(filename)
			self.reloadListView()
		except:
			qt.QMessageBox.critical(self,'Delete failed',"<qt>Failed to delete the webserver configuration \"%s\".<br><br>%s</qt>" % (filename,str(sys.exc_info()[1])))

	def startClicked(self):
		import os
		name = str(self.listview.selectedItem().text(0))
		configfile = os.path.join(self.scriptpath, os.path.join('configs',"%s.xml" % name))
		if not os.path.isfile(configfile):
			raise "There exists no such configurationfile \"%s\"" % configfile
		scriptfile = os.path.join(self.scriptpath, 'webserver.py')
		mylocals = {'__name__' : 'webservergui.py' }
		try:
			execfile(scriptfile, globals(), mylocals)
			global _main_webserverthreads
			webserverthread = mylocals.get("createWebServerThread")(self.scriptpath)
			webserverthread.webserver.config = webserverthread.webserver.readConfigFile(configfile)

			webserverthread.start()
			_main_webserverthreads[name] = webserverthread
			self.reloadListView()
		except:
			import traceback
			print "".join( traceback.format_exception(sys.exc_info()[0],sys.exc_info()[1],sys.exc_info()[2]) )
			qt.QMessageBox.critical(self,'Starting failed',"<qt>Failed to start the webserver \"%s\".<br><br>%s</qt>" % (name,str(sys.exc_info()[1])))

	def stopClicked(self):
		global qt, _main_webserverthreads
		name = str(self.listview.selectedItem().text(0))
		webserverthread = _main_webserverthreads[name]
		webserverthread.stop()
		_main_webserverthreads.__delitem__(name)
		qt.QTimer.singleShot(100, self.reloadListView)

def main(name):
	try:
		import krosskexidb
		kexidbdrivermanager = krosskexidb.DriverManager()
	except:
		raise "Failed to import the Kross KexiDB module. Please use krossrunner or Kexi to execute this python script."

	import os
	if name == "__main__":
		scriptpath = os.getcwd()
	else:
		scriptpath = os.path.dirname(name)

	global MainDialog
	dialog = MainDialog(scriptpath)
	dialog.exec_loop()

if not hasattr(__main__,'webserverthreads'):
	setattr(__main__,'webserverthreads',{})
_main_webserverthreads = __main__.webserverthreads

main(__name__)
