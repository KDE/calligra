#!/usr/bin/python

import os, sys, BaseHTTPServer

class ClientHandler(BaseHTTPServer.BaseHTTPRequestHandler):
	server_version = "KrossHTTPServer/1.0"

	def handle(self):
		#(ip, port) =  self.client_address
		#if hasattr(self, 'allowed_clients') and ip not in self.allowed_clients:
		#	self.raw_requestline = self.rfile.readline()
		#	if self.parse_request(): self.send_error(403)
		global BaseHTTPServer
		BaseHTTPServer.BaseHTTPRequestHandler.handle(self)

	def _write_header(self):
		self.send_response(200)
		self.send_header('Content-type','text/html')
		self.end_headers()
		self._write("<html><head>"
			"<title>%s</title>"
			"<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />"
			"<link rel=\"stylesheet\" type=\"text/css\" href=\"/files/%s\" />"
			"</head>\n<body>"
			"<div id=\"header\"><h1>%s</h1></div><div id=\"content\">\n" %
				(self.server.config['server']['title'], self.server.config['server']['style'], self.server.config['server']['caption']))

	def _write(self, text):
		self.wfile.write(text)

	def _write_footer(self):
		self.wfile.write("</div>\n")
		self.wfile.write('<div id="footer"><a href="/files/index.html">About</a></div>')
		self.wfile.write('</body></html>')

	def do_QUIT(self):
		""" A QUIT will be requested by e.g. webservergui.py to wake the
		WebServer up and check in the WebServer.serve_forever loop if the
		WebServer should be stopped. """
		self.send_response(200)
		self.end_headers()

	def do_GET(self):
		import os, cgi, urlparse
		(scm, netloc, path, params, qs, fragment) = urlparse.urlparse(self.path, 'http')
		query = cgi.parse_qs(qs, keep_blank_values=1)

		try:
			if len(path) <= 1:
				path = self.server.config['server']['homepage']
			(head,tail) = os.path.split(path)
			#print "=> path=\"%s\" HEAD=\"%s\" TAIL=\"%s\"" % (path,head,tail)
			if head != None and len(head) > 1:
				module = self.server.modules[ head[1:] ]
			else:
				module = self.server.modules[ path[1:] ]
		except KeyError:
			self.send_error(404,'Not Found: %s' % self.path)
			return
		try:
			module.request(self, tail, query)
		except:
			import sys, traceback
			exception = "<br>".join( traceback.format_exception(sys.exc_info()[0],sys.exc_info()[1],sys.exc_info()[2]) )
			self._write_header()
			self._write("<h2>Exception</h2><pre>%s</pre>" % exception)
			self._write_footer()

	do_HEAD = do_GET
	do_POST = do_GET
	do_PUT  = do_GET
	do_DELETE=do_GET

class WebServer(BaseHTTPServer.HTTPServer):

	def __init__(self, scriptpath, configfile = None):
		print "Initialize webserver"
		self.scriptpath = scriptpath
		if configfile != None:
			print "Using configfile %s" % configfile
			self.config = self.readConfigFile(configfile)
		else:
			print "Using default configuration"
			self.config = self.defaultConfig()
		self.modules = {}

	def defaultConfig(self):
		return {
			'server' : {
				# the address the server listen on.
				'address' : '127.0.0.1',
				# the port the server listen on.
				'port' : 8282,
				# the homepage-url where initial requests are redirected to.
				'homepage' : '/browser',

				# Title string.
				'title' : 'WebServer',
				# Caption string.
				'caption' : 'WebServer',
				# The used stylesheet file.
				'style' : 'simple.css',
			},
			'modules' : {},
		}

	def readConfigFile(self, configfile):
		print "Reading configuration"
		import os, xml.dom.minidom
		config = self.defaultConfig()
		if configfile != None and os.path.isfile(configfile):
			print "Configfile %s" % configfile
			domdoc = xml.dom.minidom.parse(configfile)
			servernode = domdoc.getElementsByTagName("Server")[0]
			for configname in ('port','address','homepage','title','caption','style'):
				attribute = servernode.getAttribute(configname)
				if attribute == None: continue
				try: config['server'][configname] = type(config['server'][configname])( attribute )
				except ValueError: pass
			for module in servernode.getElementsByTagName("Module"):
				name = module.getAttribute('name')
				file = module.getAttribute('file')
				config['modules'][name] = {'file' : file, 'moduledom' : module}
				print "Loading module name=\"%s\" file=\"%s\"" % (name, file)
		return config

	def server_bind(self):
		BaseHTTPServer.HTTPServer.server_bind(self)
		self.socket.settimeout(1)
	
	def serve_forever(self):
		self.stop = False
		while not self.stop:
			self.handle_request()

	def init(self):
		global os, BaseHTTPServer, ClientHandler
		BaseHTTPServer.HTTPServer.__init__(self, (self.config['server']['address'], self.config['server']['port']), ClientHandler)

		print "Scriptpath: %s" % self.scriptpath
		print "Trying to import modules: %s" % self.config['modules']
		self.modules = {}
		for modulename in self.config['modules']:
			print "Module: %s" % modulename
			m = os.path.join('modules',"%s.py" % modulename)
			print "Module 22222222222222222222222222222: %s" % m
			file = os.path.join(self.scriptpath,m)
			if not os.path.isfile(file):
				raise "Module file=\"%s\" does not exist" % file

			mylocals = {}
			try:
				execfile(file, globals(), mylocals)
				if mylocals.has_key("Module"):
					module = mylocals.get("Module")(self, modulename)
					self.modules[modulename] = module
				print "Imported module file=%s" % file
			except:
				print "Failed to import file=%s" % file
				import traceback
				print "".join( traceback.format_exception(sys.exc_info()[0],sys.exc_info()[1],sys.exc_info()[2]) )

	def run(self):
		try:
			print "Starting HTTP-Server %s:%s" % self.server_address[:2]
			self.serve_forever()
		except KeyboardInterrupt:
			print '^C received...'
		print "Shutting down HTTP-Server %s:%s" % self.server_address[:2]
		self.socket.close()
		self.modules = {}

def createWebServerThread(scriptpath):
	import threading
	class WebServerThread(threading.Thread):
		def __init__(self):
			import threading
			global WebServer
			threading.Thread.__init__(self)
			self.webserver = WebServer(scriptpath)
		def start(self):
			self.webserver.init()
			import threading
			threading.Thread.start(self)
		def run(self):
			self.webserver.run()
		def stop(self):
			try:
				self.webserver.stop = True
				import httplib
				conn = httplib.HTTPConnection("%s:%d" % self.webserver.server_address)
				conn.request("QUIT", "/")
				conn.getresponse()
			except:
				import sys, traceback
				print "".join( traceback.format_exception(sys.exc_info()[0],sys.exc_info()[1],sys.exc_info()[2]) )
			self._Thread__stop() # to be sure we don't freez cause of lost threads

	thread = WebServerThread()
	#thread.start()
	return thread

def main(name):
	configfile = None

	import os
	if name == "__main__":
		import sys, getopt
		def usage(): print "Usage: %s -c <configfile>" % sys.argv[0]
		scriptpath = os.getcwd()
		try:
			argv = sys.argv[1:]
			opts, args = getopt.getopt(argv, "hc:", ["help","configfile="])
		except getopt.GetoptError:
			usage()
			sys.exit(2)

		for opt, arg in opts:
			if opt in ('-h', '--help'):
				usage()
				sys.exit()
			elif opt == ('-c', '--configfile'):
				configfile = str(arg)

	else:
		scriptpath = os.path.dirname(name)

	if configfile == None:
		def callback(arg, dirname, fnames):
			print "----------> %s" % dirname
			for f in fnames:
				arg.append( os.path.join(dirname,f) )
		configfiles = []
		os.path.walk( os.path.join(scriptpath,'configs'), callback, configfiles )
		print "Available configurationfiles: %s" % configfiles
		if len(configfiles) > 0:
			configfile = configfiles[0]
			print "Using configurationfile: %s" % configfile

	if configfile != None:
		if not os.path.isfile(configfile):
			raise "There exists no such configuration file: %s" % configfile
		print "Using configuration file: %s" % configfile

	global WebServer
	webserver = WebServer(scriptpath, configfile)
	webserver.init()
	webserver.run()

import sys
if __name__ != 'webservergui.py':
	main(__name__)
