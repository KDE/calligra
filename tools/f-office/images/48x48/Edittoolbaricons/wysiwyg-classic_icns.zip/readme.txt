WYSIWYG Classic Icon Set, version 1.11
http://dryicons.com/free-icons/preview/wysiwyg-classic/

Information
----------------------

This icon set contains 47 quality icons in the following formats:
	Transparent ICNS

		128 x 128 px



Licensing
----------------------

The usage of DryIcons' work (icons, icon sets and graphics) is limited to the terms of the "Free License" and "Commercial License" use.
The DryIcons Free License means that you can use our icons, icon sets and graphics in any publicly accesible web site, web application or any form of presentation publicly accessible through the World Wide Web only according to the DryIcons Free License Terms and Conditions:

* You must put a back link with credits to http://dryicons.com on every page where DryIcons' Works are used (example: Icons by http://dryicons.com);

* You must include the correct back link to DryIcons website, which is: http://dryicons.com;

* You must place the link on an easy-to-see, recognizable place, so there is no confusion about the Original Author of the Works (DryIcons);

* When copying, or paraphrasing description text (or title) on one of the Works, you must make sure there are no spelling mistakes;

* Do not try to take credit or imply in any way that you and not DryIcons is the Original Author of the Works (icons, icon sets and graphics).

For a more detailed look at our Free License Agreement, please follow the link: http://dryicons.com/terms/#free-license


The DryIcons Commercial License means that you can use our Free Icon Sets and Free Graphics without being obligated to put a back link to DryIcons.com for a certain fee. After you complete yourpayment transaction DryIcons grants you a Commercial License.

For a more detailed look at our Commercial License Agreement, please follow the link: http://dryicons.com/terms/#commercial-license
